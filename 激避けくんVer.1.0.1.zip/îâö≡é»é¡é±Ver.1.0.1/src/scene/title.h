#pragma once
#include "sceneCommon.h"
class Title : public SceneCommon
{

	Vec2f bg_pos;
	Vec2f bg_size;
	Vec2f bg_cut_pos;
	Vec2f bg_cut_size;
	float velocity;

	Font font;
	Font font_key;
	Color color;
	
	Texture bg_img;
	

	bool is_change;

public:

	Title();
	~Title();

	void Update();
	void Draw();
	void Setup();

	void ProductKey();
	int SceneEnd();

};