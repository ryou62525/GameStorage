#include "title.h"

Title::Title() :
	font("res/yugothib.ttf"),
	font_key("res/yugothib.ttf"),
	bg_img("res/title_img.png")	
{
	Setup();
}

Title::~Title()
{
	
}

void Title::Setup()
{

	bg_pos = Vec2f(-WIDTH / 2, -HEIGHT / 2);
	bg_size = Vec2f(WIDTH, HEIGHT);
	bg_cut_pos = Vec2f::Zero();
	bg_cut_size = Vec2f(512, 1024);
	velocity = 1.0f;

	pos = Vec2f(-125, 260);
	is_end = false;

	font.size(50);
	font_key.size(30);

	is_change = false;
	color = Color(0, 0, 0, 1);
	
}

void Title::Update()
{
	
	ProductKey();
	
	bg_cut_pos.x() -= velocity;

	if (App::Get().isPushKey(GLFW_KEY_ENTER))
	{
		is_end = true;		
	}
}

void Title::Draw()
{
	drawTextureBox(bg_pos.x(), bg_pos.y(), bg_size.x(), bg_size.y(), bg_cut_pos.x(), bg_cut_pos.y(), bg_cut_size.x(), bg_cut_size.y(), bg_img);
	font.draw("����������", pos, Color::black);
	font_key.draw("PRESS ENTER KEY !", Vec2f(-150, 30), color);
}

//PUSH ENTER KEY�̉��o�p�֐�
void Title::ProductKey()
{
	if (color.a() >= 1)
	{
		is_change = false;
	}

	if (color.a() <= 0.01)
	{
		is_change = true;
	}

	if (!is_change)
	{
		color.a() -= 0.02f;
	}

	if (is_change)
	{
		color.a() += 0.02f;
	}
}

int Title::SceneEnd()
{
	if (is_end == true)
	{
		return MENU;
	}
	return TITLE;
}