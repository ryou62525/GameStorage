#include "gameManager.h"
#include <iostream>

GameManager::GameManager() :
	font("res/yugothic.ttf"),
	pause_menu("res/yugothic.ttf"),
	pause_icon("res/doll.png"),
	bg_img("res/game_bg.png"),
	bgm("res/game_main.wav")
{
	pos[0] = Vec2f(0, -350);
	pos[1] = Vec2f(-WIDTH / 2, -HEIGHT / 2);
	size[0] = Vec2f(WIDTH, HEIGHT);
	corner_pos = Vec2f(-WIDTH / 2, -270);

	menu_pos[0] = Vec2f(-100, 0);
	menu_pos[1] = Vec2f(-100, -50);
	icon_pos = Vec2f(-150, -5);
	icon_size = Vec2f(32, 32);

	score_pos[Score::FONT_POS] = Vec2f(-150, 270);
	hiscore_pos = Vec2f(-175, 270);

	player = new Player;

	rand.setSeed(time(nullptr));

	create_counter = 50;
	time_counter = 0;
	avoid_counter = 0;

	count_text = std::to_string(avoid_counter);

	color = Color(0, 0, 0, 0.5f);
	menu_select = (int)MenuSelect::NOT;

	is_pause = false;
	game_stop = false;
	in_result = false;
	is_highscore = false;

	font.size(50);
	pause_menu.size(30);
	bgm.play();

}

GameManager::~GameManager()
{
	delete player;
}

bool obJectErase(FallObject* fallobj)
{
	return !fallobj->isActive();
}



void GameManager::Update()
{
	bgm.looping(true);
	LoadHighScore();

	//�|�[�Y��ʈڍs����
	if (menu_select == (int)MenuSelect::NOT && App::Get().isPushKey(GLFW_KEY_SPACE))
	{
		menu_select = (int)MenuSelect::MENU_1;
		is_pause = true;
	}

	//�Q�[�����C��
	if (is_pause == false && player->checkState() == true)
	{
		player->Update();

		if (isCreation())
		{
			fall_obj.push_back(new FallObject(Vec2f(rand(-WIDTH / 2, WIDTH / 2 - 64), HEIGHT / 2), Vec2f(64, 64)));
		}

		if (player->getPos().x() == corner_pos.x() || player->getPos().x() >= -corner_pos.x() - 64.0f)
		{
			if (count.timeCounter(3.0f))
			{
				fall_obj.push_back(new FallObject(Vec2f(player->getPos().x(), 480), Vec2f(64, 64)));
				count.resetCount(0);
			}
		}

		if (changeCreateSpeed() && create_counter >= 10)
		{
			create_counter -= 2;
		}

		//�������񐔕��̐��l���o�͗p�ϐ��Ɋi�[
		count_text = std::to_string(avoid_counter);

		std::list<FallObject*>::iterator it = fall_obj.begin();
		while (it != fall_obj.end())
		{
			(*it)->Update();

			//�G�I�u�W�F�N�g���������Ɠ����ɔ������񐔕��J�E���g�𑝂₷
			if ((*it)->isActive() == false)
			{
				avoid_counter += 1;
			}

			if (isHit::ToRect(player->getPos() + Vec2f(30, 30), player->getSize() - Vec2f(60, 60), (*it)->getPos(), (*it)->getSize()))
			{
				player->IsActive(false);
			}
			it++;
		}
	}

	//�|�[�Y���̑���
	if (is_pause == true)
	{
		switch (menu_select)
		{
		case (int)MenuSelect::MENU_1:

			if (App::Get().isPushKey(GLFW_KEY_DOWN))
			{
				icon_pos = Vec2f(-150, -55);
				menu_select = (int)MenuSelect::MENU_2;
			}

			//�|�[�Y���Q�[���ɖ߂鏈��
			if (menu_select == (int)MenuSelect::MENU_1 && App::Get().isPushKey(GLFW_KEY_ENTER))
			{
				menu_select = (int)MenuSelect::NOT;
				is_pause = false;
			}

			break;
		case (int)MenuSelect::MENU_2:

			if (App::Get().isPushKey(GLFW_KEY_UP))
			{
				icon_pos = Vec2f(-150, -5);
				menu_select = (int)MenuSelect::MENU_1;
			}

			//�|�[�Y����Q�[���𒆒f���鏈��
			if (menu_select == (int)MenuSelect::MENU_2 && App::Get().isPushKey(GLFW_KEY_ENTER)) { game_stop = true; }

			break;
		}
	}

	//--------------------------//
	//		  ���U���g���		//
	//--------------------------//

	if (player->checkState() == false)
	{
		SettingPos();
		ScoreDecision();
		if (count.timeCounter(2.0f)) { in_result = true; }
	}

	//�X�R�A��������
	if (is_highscore == true) { WritingScore(); }

	if (in_result == true)
	{
		if (App::Get().isPushKey(GLFW_KEY_ENTER)) { result_end = true; }
	}

	fall_obj.remove_if(obJectErase);
}

void GameManager::Draw()
{
	drawTextureBox(-WIDTH / 2, -HEIGHT / 2, WIDTH, HEIGHT, 0, 0, 512, 1024, bg_img);
	player->Draw();
	UiDarw();

	std::list<FallObject*>::iterator it = fall_obj.begin();
	while (it != fall_obj.end())
	{
		(*it)->Draw();
		it++;
	}

	//-----------------------------------------------------
	if (is_pause == true)
	{
		drawFillBox(pos[1].x(), pos[1].y(), size[0].x(), size[0].y(), color);
		drawTextureBox(icon_pos.x(), icon_pos.y(), icon_size.x(), icon_size.y(), 0, 0, 512, 512, pause_icon);

		font.draw("-PAUSE-", Vec2f(-100, 100), Color::white);
		pause_menu.draw("�Q�[���ɂ��ǂ�", menu_pos[0], Color::white);
		pause_menu.draw("��߂�", menu_pos[1], Color::white);
	}
	//-----------------------------------------------------
	if (in_result == true)
	{
		if (is_highscore == true)
		{
			HighScoreDraw();
		}
		else
		{
			ScoreDraw();
		}
	}

}

//�I�u�W�F�N�g�����������^�C�~���O�����߂�
bool GameManager::isCreation()
{
	time_counter++;
	if (time_counter % create_counter == 0)
	{
		return true;
	}
	return false;
}

//�J�E���g�ɂ���ăI�u�W�F�N�g�����������^�C�~���O���͂���֐�
bool GameManager::changeCreateSpeed()
{
	if (time_counter % 200 == 0)
	{
		return true;
	}
	return false;
}

bool GameManager::isGameEnd()
{
	if (result_end == true || game_stop == true)
	{
		bgm.stop();
		return true;
	}
	return false;
}

void GameManager::UiDarw()
{
	Vec2f pos(-WIDTH / 2, -450);
	Vec2f size(WIDTH, 180);
	Color color = Color(0, 0, 0, 0.5f);

	drawFillBox(pos.x(), pos.y(), size.x(), size.y(), color);

	font.draw("SCORE", Vec2f(-250, -350), Color(255, 255, 255));
	font.draw("HISCORE", Vec2f(-250, -400), Color(255, 255, 255));

	std::to_string(avoid_counter);
	font.draw(count_text, Vec2f(30, -350), Color::white);
	font.draw(score_disp, Vec2f(30, -400), Color::white);
}

void GameManager::ScoreDraw()
{
	std::fstream file;

	file.open("res/score.txt", std::ios::in);
	assert(!file.is_open());

	std::string current_hiscore;
	std::getline(file, current_hiscore);

	Vec2f set_pos(0, 300);

	drawFillBox(pos[1].x(), pos[1].y(), size[0].x(), size[0].y(), color);
	font.draw("����̃X�R�A", score_pos[0], Color::white);
	font.draw(count_text, score_pos[Score::NUM_POS], Color::white);

	font.draw("���݂̃n�C�X�R�A", hiscore_pos - set_pos, Color::white);
	font.draw(current_hiscore, score_pos[Score::NUM_POS] - set_pos, Color::white);
}

void GameManager::HighScoreDraw()
{
	drawFillBox(pos[1].x(), pos[1].y(), size[0].x(), size[0].y(), color);
	font.draw("�n�C�X�R�A�I�I", hiscore_pos, Color::white);
	font.draw(count_text, score_pos[Score::NUM_POS], Color::white);
}

//���݂̃n�C�X�R�A���t�@�C������ǂݍ���
void GameManager::LoadHighScore()
{
	std::fstream file("res/score.txt", std::ios::in);
	std::string str;

//	file.open("res/score.txt", std::ios::in);
//	assert(!file.is_open());
	assert(file);

	std::getline(file, str);

	if (str == "")
	{
		file.close();
		return;
	}

	//�������int�^�ɕϊ�
	num = std::stoi(str);
	score_disp = str;

	file.close();
}

void GameManager::WritingScore()
{
	std::fstream file;

	file.open("res/score.txt", std::ios::out);
	assert(!file.is_open());

	num = avoid_counter;
	file << num;

	file.close();
}

//���݂̃n�C�X�R�A�ƍ���̹ްт̃X�R�A���r���n�C�X�R�A���ǂ������肷�� 
void GameManager::ScoreDecision()
{
	LoadHighScore();
	if (avoid_counter > num) { is_highscore = true; }
}

//�X�R�A�\���ꏊ�̔�����
void GameManager::SettingPos()
{
	if (avoid_counter <= 10) { score_pos[Score::NUM_POS] = Vec2f(-15, 100); }
	if (avoid_counter >= 10 && avoid_counter <= 100) { score_pos[Score::NUM_POS] = Vec2f(-15, 100); }
	if (avoid_counter >= 100 && avoid_counter <= 1000) { score_pos[Score::NUM_POS] = Vec2f(-45, 100); }
}

void GameManager::Reset()
{
	pos[0] = Vec2f(0, -400);

	player = new Player;

	create_counter = 50;
	time_counter = 0;
	avoid_counter = 0;

	is_pause = false;
}