#pragma once
#include "title.h"
#include "menu.h"
#include "game.h"

class SceneManager
{
	SceneCommon* current_scene;
	Media bgm;

public:

	SceneManager();
	~SceneManager();

	void Update();
	void Draw();
	void Setup();

	void SetScene(int);
	void DeleteScene();

	int SceneEnd();

};