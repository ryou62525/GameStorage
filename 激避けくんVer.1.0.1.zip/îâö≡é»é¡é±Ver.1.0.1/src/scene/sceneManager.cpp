#include "sceneManager.h"

SceneManager::SceneManager():
	bgm("res/snow_orc.wav")
{
	current_scene = new Title;
}

SceneManager::~SceneManager()
{
}

void SceneManager::Update()
{
	current_scene->Update();
}

void SceneManager::Draw()
{
	current_scene->Draw();
}

void SceneManager::Setup()
{

}

void SceneManager::SetScene(int scene_name)
{
	if (scene_name != SceneNum::TITLE) { bgm.stop(); }

	switch (scene_name)
	{
	case SceneNum::TITLE:
		
		bgm.play();
		bgm.looping(true);

		DeleteScene();
		current_scene = new Title;

		break;
	case SceneNum::MENU:

		DeleteScene();
		current_scene = new Menu;

		break;
	case SceneNum::GAME:

		DeleteScene();
		current_scene = new Game;

		break;	
	}
}

void SceneManager::DeleteScene()
{
	delete current_scene;
}

int SceneManager::SceneEnd()
{
	return current_scene->SceneEnd();
}
