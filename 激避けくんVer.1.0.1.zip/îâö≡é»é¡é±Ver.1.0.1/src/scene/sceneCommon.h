#pragma once
#include <iostream>
#include "../base/common.h"
#include "../base/timeCount.h"

enum SceneNum
{
	NON,
	TITLE,
	MENU,
	GAME,
	RESULT,
	EMPTY,
};

class SceneCommon
{
protected:

	Vec2f pos;
	Vec2f size;

	SceneNum scene_num;
	TimeCount time_counter;
	bool is_end;

public:

	virtual void Update() = 0;
	virtual void Draw() = 0;
	virtual void Setup() = 0;
	virtual int SceneEnd() = 0;

};