#pragma once
#include "sceneCommon.h"

class Menu : public SceneCommon
{

	Font font;
	Media bgm;

	Vec2f menu_pos[3];
	Vec2f icon_pos;
	Vec2f icon_size;

	Texture img;
	Texture icon;

	int menu_select;
	bool isOperate;

public:

	Menu();
	~Menu();

	void Update();
	void Draw();
	void Setup();

	void GuideDraw();
	int SceneEnd();

};