﻿
#include "../src/scene/game.h"
#include "base/app.h"
#include "scene/sceneManager.h"


int main() {

	App::Get();

	SceneManager scene_manager;

	int current_scene = SceneNum::NON;
	int next_scene = SceneNum::TITLE;

  while (App::Get().isOpen()) {
    
	  if (next_scene != current_scene)
	  {
		  current_scene = next_scene;
		  scene_manager.SetScene(current_scene);
	  }

	  scene_manager.Update();

	  App::Get().begin();
    
	  scene_manager.Draw();
	

	  next_scene = scene_manager.SceneEnd();


	  if (App::Get().isPushKey(GLFW_KEY_ESCAPE))
	  {
		  break;
	  }

	  App::Get().end();
  }
}