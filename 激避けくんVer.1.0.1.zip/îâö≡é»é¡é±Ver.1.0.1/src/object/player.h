#pragma once
#include "object.h"

class Player : public Object
{
	Texture player_img;
	int press_direction;

	Vec2f offset;

	int animation_count;
	int animation_index;

public:

	Player();
	~Player();

	void Setup();
	void Update();
	void Draw();
	void Move();

	void PressWhere();
	void clipCulc();
	void IsActive(bool);
	bool checkState() { return is_active; }

};