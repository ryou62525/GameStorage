#include "timeCount.h"

TimeCount::TimeCount()
{
	time_count = 0;
}

bool TimeCount::timeCounter(float time)
{
	float count = time * 60;
	time_count += 1;

	if (time_count > count)
	{
		return true;
	}
	return false;
}

int TimeCount::getTimeCount()
{
	return time_count;
}

void TimeCount::resetCount(int riset_time)
{
	time_count = riset_time;
}
