#pragma once
#include "../lib/framework.hpp"

enum Window 
{
	WIDTH = 512,
	HEIGHT = 900
};

class App
{
public:

	static AppEnv& Get()
	{
		static AppEnv env(WIDTH, HEIGHT, false, false);
		return env;
	}

};

