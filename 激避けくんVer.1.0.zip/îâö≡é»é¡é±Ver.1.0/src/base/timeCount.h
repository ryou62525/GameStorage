#pragma once
#include "common.h"

class TimeCount
{
private:

	int time_count;

public:

	TimeCount();
	
	bool timeCounter(float);
	int getTimeCount();
	void resetCount(int);

};