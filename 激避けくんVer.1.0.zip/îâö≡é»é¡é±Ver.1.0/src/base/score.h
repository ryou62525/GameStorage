#pragma once

#include <string>
#include <sstream>

#include "common.h"

class Score
{

};