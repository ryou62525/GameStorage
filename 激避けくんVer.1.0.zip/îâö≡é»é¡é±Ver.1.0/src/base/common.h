#pragma once

#include "app.h"
#include "../lib/framework.hpp"

#include <string>


enum class Direction
{
	UP,
	DOWN,
	RIGHT,
	LEFT,
	NOT,
};

enum class MenuSelect
{
	NOT,
	MENU_1,
	MENU_2,
	MENU_3,
};

namespace isHit
{
	//��`���m�̓����蔻��
	static bool ToRect(Vec2f pos_1, Vec2f size_1, Vec2f pos_2, Vec2f size_2)
	{
		return (pos_1.x() + size_1.x() >= pos_2.x() && pos_1.x() <= pos_2.x() + size_2.x()
			&& pos_1.y() + size_1.y() >= pos_2.y() && pos_1.y() <= pos_2.y() + size_2.y());
	}

	//���`���m�̓����蔻��
	static bool ToCircle(Vec2f pos_1, Vec2f size_1, Vec2f pos_2, Vec2f size_2)
	{
		return ((pos_1.x() - pos_2.x()) * (pos_1.x() - pos_2.x()) + (pos_1.y() - pos_2.y()) * (pos_1.y() - pos_2.y()) >= (size_1.x() + size_2.x()));
	}

}