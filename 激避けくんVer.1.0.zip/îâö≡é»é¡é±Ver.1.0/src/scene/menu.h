#pragma once
#include "sceneCommon.h"

class Menu : public SceneCommon
{

	Font font;
	Media bgm;

	Vec2f menu_pos[3];
	Vec2f icon_pos;
	Vec2f icon_size;

	Texture img;
	Texture icon;

	int menu_select;

public:

	Menu();
	~Menu();

	void Update();
	void Draw();
	void Setup();

	int SceneEnd();

};