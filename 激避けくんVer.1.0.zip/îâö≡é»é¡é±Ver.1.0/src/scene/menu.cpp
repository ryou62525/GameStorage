#include "menu.h"

Menu::Menu() :
	font("res/yugothib.ttf"),
	img("res/test.png"),
	bgm("res/game_menu.wav"),
	icon("res/doll.png")
{
	pos = Vec2f(-80, 350);

	menu_pos[0] = Vec2f(-140, 100);
	menu_pos[1] = Vec2f(-175, -50);
	menu_pos[2] = Vec2f(-100, -200);

	icon_pos = Vec2f(-225, 100);
	icon_size = Vec2f(32, 32);

	is_end = false;
	font.size(40);
	bgm.play();

	menu_select = (int)MenuSelect::MENU_1;
}

Menu::~Menu()
{

}

void Menu::Update()
{
	bgm.looping(true);

	switch (menu_select)
	{
	case (int)MenuSelect::MENU_1:

		if (App::Get().isPushKey(GLFW_KEY_ENTER))
		{
			is_end = true;
			bgm.stop();
		}

		if (App::Get().isPushKey(GLFW_KEY_DOWN))
		{
			icon_pos.y() = -50;
			menu_select = (int)MenuSelect::MENU_2;
		}
		break;

	case (int)MenuSelect::MENU_2:

		if (App::Get().isPushKey(GLFW_KEY_ENTER))
		{
		}

		if (App::Get().isPushKey(GLFW_KEY_UP))
		{
			icon_pos.y() = 100;
			menu_select = (int)MenuSelect::MENU_1;
		}

		if (App::Get().isPushKey(GLFW_KEY_DOWN))
		{
			icon_pos.y() = -200;
			menu_select = (int)MenuSelect::MENU_3;
		}

		break;

	case (int)MenuSelect::MENU_3:

		if (App::Get().isPushKey(GLFW_KEY_ENTER))
		{
		}

		if (App::Get().isPushKey(GLFW_KEY_UP))
		{
			icon_pos.y() = -50;
			menu_select = (int)MenuSelect::MENU_2;
		}

		break;

	default:

		break;
	}


}

void Menu::Draw()
{
	font.draw("���j���[", pos, Color::white);
	font.draw("�Q�[���X�^�[�g", menu_pos[0], Color::white);
	/*font.draw("�ӂ����̂������", menu_pos[1], Color::white);
	font.draw("�I�v�V����", menu_pos[2], Color::white);*/

	drawTextureBox(icon_pos.x(), icon_pos.y(), icon_size.x(), icon_size.y(), 0, 0, 512, 512, icon);

	/*drawTextureBox(menu_pos[1].x() + 10, menu_pos[1].y() - 65, 320, 160, 0, 0, 256, 128, img);
	drawTextureBox(menu_pos[2].x() - 60, menu_pos[2].y() - 60, 320, 160, 0, 0, 256, 128, img);*/
}

void Menu::Setup()
{

}

int Menu::SceneEnd()
{
	if (is_end == true)
	{
		return SceneNum::GAME;
	}
	return SceneNum::MENU;
}
