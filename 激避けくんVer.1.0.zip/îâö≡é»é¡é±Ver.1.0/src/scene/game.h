#pragma once
#include "sceneCommon.h"
#include "gameManager.h"


class Game : public SceneCommon
{

	GameManager *game_manager;
	Font font;

	Vec2f font_pos;

	bool is_start;
	bool draw_text1;
	bool draw_text2;

public:

	Game();
	~Game();

	void Update();
	void Draw();
	void Setup();

	int SceneEnd();

};