#pragma once

#include <list>
#include <string>
#include <fstream>

#include "../object/fallObject.h"
#include "../object/player.h"
#include "../base/timeCount.h"

enum Score
{
	FONT_POS,
	NUM_POS,
	MAX_POS
};

class GameManager
{
	Vec2f pos[2];
	Vec2f size[1];
	Vec2f corner_pos;

	Vec2f menu_pos[2];
	Vec2f icon_pos;
	Vec2f icon_size;

	Vec2f score_pos[MAX_POS];
	Vec2f hiscore_pos;

	Player *player;

	Font font;
	Font pause_menu;

	Random rand;
	Color color;
	Media bgm;

	Texture bg_img;
	Texture pause_icon;
	TimeCount count;

	std::fstream file;
	//std::string str;
	std::list<FallObject*> fall_obj;
	int num;
	
	int menu_select;
	int time_counter;	//�I�u�W�F�N�g�𐶐�����l���i�[����ϐ�
	int create_counter;	//�����������^�C�~���O�̒l���i�[����ϐ�
	int avoid_counter;	//�������񐔂��i�[����ϐ�

	bool is_pause;
	bool game_stop;
	bool in_result;
	bool result_end;
	bool is_highscore;
	std::string count_text;

public:

	GameManager();
	~GameManager();

	void Update();
	void Reset();
	void Draw();

	void ScoreDraw();
	void HighScoreDraw();
	void ScoreDecision();
	void LoadHighScore();
	void WritingScore();

	void SettingPos();
	bool isCreation();
	bool changeCreateSpeed();
	bool isGameEnd();

	void UserInterface();
};