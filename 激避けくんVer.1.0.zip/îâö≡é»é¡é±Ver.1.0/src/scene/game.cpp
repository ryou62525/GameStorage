#include "game.h"

Game::Game():
	font("res/yugothic.ttf")
{
	game_manager = new GameManager;
	
	font_pos = Vec2f(-45, 100);
	
	is_start = false;
	draw_text1 = true;
	draw_text2 = false;
	font.size(30);
}

Game::~Game()
{
	delete game_manager;
}

void Game::Update()
{
	if (time_counter.timeCounter(3.0f))
	{
		is_start = true;
		draw_text1 = false;
		draw_text2 = true;
	}
	if (time_counter.timeCounter(5.0f))
	{
		draw_text2 = false;
	}

	if (is_start == true)
	{
		game_manager->Update();
	}

	if (game_manager->isGameEnd())
	{
		
		is_end = true;
	}

}

void Game::Draw()
{
	game_manager->Draw();

	if (draw_text1 == true)
	{
		font.draw("READY", font_pos, Color::white);
	}

	if (draw_text2 == true)
	{
		font.draw("START!", font_pos, Color::white);
	}

}

void Game::Setup()
{

}

int Game::SceneEnd()
{
	if (is_end == true)
	{
		return SceneNum::TITLE;
	}
	return SceneNum::GAME;
}