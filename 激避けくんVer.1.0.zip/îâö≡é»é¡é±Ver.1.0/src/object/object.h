#pragma once
#include "../base/common.h"


class Object
{
protected:

	Vec2f pos;
	Vec2f size;
	float velocity;

	bool is_active;

public:

	Vec2f getPos() { return pos; }
	Vec2f getSize() { return size; }

};