#include "player.h"

Player::Player() :
	player_img("res/player.png")
{
	Setup();
}

Player::~Player()
{

}

void Player::Setup()
{
	pos = Vec2f(-32, -270);
	size = Vec2f(64, 64);
	velocity = 8.0f;
	is_active = true;
	press_direction = (int)Direction::NOT;

	offset.x() = 0.0f;
	offset.y() = 0.0f;

	animation_count = 0;
	animation_index = 0;
}

void Player::Update()
{
	PressWhere();
	Move();
}

void Player::Draw()
{
	//drawFillBox(pos.x(), pos.y(), size.x(), size.y(), Color::red);
	clipCulc();
	drawTextureBox(pos.x(), pos.y(), size.x(), size.y(), offset.x(), offset.y(), 32, 32, player_img);
}

void Player::Move()
{
	if (App::Get().isPressKey(GLFW_KEY_RIGHT))pos.x() += velocity;
	if (App::Get().isPressKey(GLFW_KEY_LEFT))pos.x() -= velocity;

	if (pos.x() >= WIDTH / 2 - size.x() + 1.5f) { pos.x() -= velocity; }
	if (pos.x() <= -WIDTH / 2 - 1.5f) { pos.x() += velocity; }
}

void Player::PressWhere()
{
	if (App::Get().isPushKey(GLFW_KEY_RIGHT)) { press_direction = (int)Direction::RIGHT; }
	if (App::Get().isPushKey(GLFW_KEY_LEFT)) { press_direction = (int)Direction::LEFT; }
}

//�A�j���[�V�����؂���v�Z�p�֐�
void Player::clipCulc()
{
	animation_count += 1;
	animation_index = (animation_count / 10) % 3;

	if (press_direction == (int)Direction::RIGHT)
	{
		int index_tbl[] = { 6, 8, 6, 8 };
		offset.x() = (index_tbl[animation_index] % 3) * 32;
		offset.y() = (index_tbl[animation_index] / 3) * 32;
	}

	if (press_direction == (int)Direction::LEFT)
	{
		int index_tbl[] = { 3, 5, 3, 5 };
		offset.x() = (index_tbl[animation_index] % 3) * 32;
		offset.y() = (index_tbl[animation_index] / 3) * 32;
	}
}

//�I�u�W�F�N�g�ɓ������Ă��܂������̃t���O�̕ύX
void Player::IsActive(bool isActive)
{
	is_active = isActive;
}
