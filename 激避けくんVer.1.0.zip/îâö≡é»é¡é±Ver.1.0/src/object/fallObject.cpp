#include "fallObject.h"

FallObject::FallObject(Vec2f pos, Vec2f size):
	image("res/doll.png")
{
	this->pos = pos;
	this->size = size;

	rand.setSeed(time(nullptr));
	gravity = rand(0.01f, 0.98f);
	vec = 0;

	is_active = true;
}

FallObject::~FallObject()
{

}

void FallObject::Update()
{
	vec -= gravity;
	pos.y() += vec;
	
	if (App::Get().isPushKey('W')) { gravity = 0.44f; }
	if (pos.y() <= -HEIGHT / 2 - size.x())is_active = false;

}

void FallObject::Draw()
{
	drawTextureBox(pos.x(), pos.y(), size.x(), size.y(), 0, 0, 512, 512, image);
}

void FallObject::Reset()
{
	vec = 0;
	gravity = 0.98f;
	is_active = true;
}