#pragma once
#include "object.h"

class FallObject : public Object
{
	
	float vec;
	float gravity;
	
	Random rand;
	Texture image;

public:

	FallObject(Vec2f pos, Vec2f size);
	~FallObject();

	void Update();
	void Draw();
	void Reset();
	bool isActive() { return is_active; }

};